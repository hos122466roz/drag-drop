
export const Data = [
  {
    id: 1,
    src: "./image/product/1-symbol.jpg",
  },
  {
    id: 2,
    src: "./image/product/5-symbol.jpg",
  },
  {
    id: 3,
    src: "./image/product/8-symbol.jpg",
  },
  {
    id: 4,
    src: "./image/product/6-symbol.jpg",
  },
  {
    id: 5,
    src: "./image/product/27-symbol.jpg",
  },
  {
    id: 6,
    src: "./image/product/8-symbol.jpg",
  },
  {
    id: 7,
    src: "./image/product/37-symbol.jpg",
  },
  {
    id: 8,
    src: "./image/product/40-symbol.jpg",
  },
  {
    id: 9,
    src: "./image/product/41-symbol.jpg",
  },
  {
    id: 10,
    src: "./image/product/42-symbol.jpg",
  },
  {
    id: 11,
    src: "./image/product/43-symbol.jpg",
  },
  {
    id: 12,
    src: "./image/product/45-symbol.jpg",
  },
  
 
];

export const dorpbox = [
  {
    id: 1,
    src: "./image/product/1-symbol.jpg",
  },
  {
    id: 2,
    src: "./image/product/1-symbol.jpg",
  },
  {
    id: 3,
    src: "./image/product/1-symbol.jpg",
  },
  {
    id: 4,
    src: "./image/product/1-symbol.jpg",
  },
  {
    id: 5,
    src: "./image/product/1-symbol.jpg",
  },
  {
    id: 6,
    src: null,
  },

];
