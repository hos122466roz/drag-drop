import img from "../../../public/image/4-symbol.jpg";
import img1 from "../../../public/image/1-symbol.jpg";
export const Data = [
  {
    id: 1,
    img: img,
  },
  {
    id: 2,
    img: img1,
  },
  {
    id: 3,
    img: img,
  },
  {
    id: 4,
    img: img1,
  },
  {
    id: 5,
    img: img1,
  },
  {
    id: 6,
    img: img,
  },
  {
    id: 7,
    img: img,
  },
  {
    id: 8,
    img: img,
  },
  {
    id: 9,
    img: img,
  },
  {
    id: 10,
    img: img,
  },
  {
    id: 11,
    img: img,
  },
  {
    id: 12,
    img: img1,
  },
  {
    id: 13,
    img: img,
  },
  {
    id: 14,
    img: img,
  },
  {
    id: 15,
    img: img,
  },
  {
    id: 16,
    img: img,
  },
  {
    id: 17,
    img: img,
  },
  {
    id: 18,
    img: img,
  },
  {
    id: 19,
    img: img,
  },
  {
    id: 20,
    img: img,
  },
];

export const dorpbox = [
  {
    id: 1,
  },
  {
    id: 2,
  },
  {
    id: 3,
  },
  {
    id: 4,
  },
  {
    id: 5,
  },
  {
    id: 6,
  },
  {
    id: 7,
  },
  {
    id: 8,
  },
  {
    id: 9,
  },
  {
    id: 10,
  },
  {
    id: 11,
  },
  {
    id: 12,
  },
  {
    id: 13,
  },
  {
    id: 14,
  },
  {
    id: 15,
  },
  {
    id: 16,
  },
];
